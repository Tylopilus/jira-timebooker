(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-7949e6ab.js")
    );
  })().catch(console.error);

})();
