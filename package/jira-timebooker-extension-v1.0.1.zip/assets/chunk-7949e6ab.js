import { r as requiredArgs, t as toDate, g as getLocaleFromDocument, p as parseCalenderDateString, c as createHash, a as getIssueKeyForMeetingName } from "./chunk-4ed936f1.js";
function differenceInMilliseconds(dateLeft, dateRight) {
  requiredArgs(2, arguments);
  return toDate(dateLeft).getTime() - toDate(dateRight).getTime();
}
console.info("chrome-ext template-react-ts content script");
async function getMeetings() {
  const meetingElements = [...document.querySelectorAll("div[role=button][class^=root]")];
  if (!meetingElements.length)
    throw new Error("No meetings found");
  const meetings = await Promise.all(
    meetingElements.map(async (el) => {
      var _a, _b;
      const matchedLabel = (_a = el.ariaLabel) == null ? void 0 : _a.match(/(\d{2}:\d{2}).*(\d{2}:\d{2})/i);
      const start = matchedLabel ? matchedLabel[1] : "00:00";
      const end = matchedLabel ? matchedLabel[2] : "00:00";
      const date = getSelectedDay();
      const locale = getLocaleFromDocument(document.documentElement.lang);
      const startTime = await parseCalenderDateString(date, start, locale);
      const endTime = await parseCalenderDateString(date, end, locale);
      const duration = String(differenceInMilliseconds(new Date(endTime), new Date(startTime)));
      const title = ((_b = el.getAttribute("title")) == null ? void 0 : _b.split("\n")[0].trim()) ?? "No title";
      const id = await createHash([title, startTime, endTime].join(""));
      const ticketMatch = title.match(/\w+-\d+\s/i);
      const issueForMeeting = await getIssueKeyForMeetingName(title);
      const ticket = ticketMatch ? ticketMatch[0].trim() : issueForMeeting;
      return {
        id,
        startTime,
        endTime,
        duration,
        start,
        end,
        title,
        ticket,
        booked: false,
        pending: false
      };
    })
  );
  return meetings;
}
function getSelectedDay() {
  const date = document.querySelector("#leftPaneContainer").querySelector("[aria-selected=true] button").getAttribute("aria-label");
  return date;
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message === "getCalEntries") {
    getMeetings().then((meetings) => {
      console.log("sending..", meetings);
      sendResponse(meetings);
    });
  }
  if (message === "getSelectedDay") {
    const selectedDay = getSelectedDay();
    sendResponse(selectedDay);
  }
  return true;
});
