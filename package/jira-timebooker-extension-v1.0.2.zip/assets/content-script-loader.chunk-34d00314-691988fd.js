(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-34d00314.js")
    );
  })().catch(console.error);

})();
