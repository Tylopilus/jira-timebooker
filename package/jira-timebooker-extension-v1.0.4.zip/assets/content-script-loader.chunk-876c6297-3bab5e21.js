(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-876c6297.js")
    );
  })().catch(console.error);

})();
