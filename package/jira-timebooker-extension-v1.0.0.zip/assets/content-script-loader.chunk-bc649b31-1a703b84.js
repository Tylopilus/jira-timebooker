(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-bc649b31.js")
    );
  })().catch(console.error);

})();
