(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-cac8ae28.js")
    );
  })().catch(console.error);

})();
