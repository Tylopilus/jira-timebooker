(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-38ef70a0.js")
    );
  })().catch(console.error);

})();
