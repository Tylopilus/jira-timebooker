function getAggregatedMeetings(meetings, todaysMeetings, bookedMeetingTitles) {
  const aggregatedMeetings = meetings.map((meeting) => {
    const booked = todaysMeetings.includes(meeting.id);
    const aggregatedMeeting = {
      ...meeting,
      booked
    };
    if (booked) {
      for (const [key, value] of Object.entries(bookedMeetingTitles)) {
        if (key === meeting.title) {
          aggregatedMeeting.ticket = value;
        }
      }
    }
    return aggregatedMeeting;
  });
  return aggregatedMeetings;
}
async function getSelectedDay() {
  const selectedDay = await chrome.runtime.sendMessage("getSelectedDay");
  return new Date(selectedDay).toLocaleDateString();
}
async function addMeetingBookedByDay(today, meeting) {
  const { meetingsBookedByDay = {} } = await chrome.storage.sync.get("meetingsBookedByDay");
  if (meetingsBookedByDay[today]) {
    meetingsBookedByDay[today].push(meeting.id);
  } else {
    meetingsBookedByDay[today] = [meeting.id];
  }
  chrome.storage.sync.set({ meetingsBookedByDay });
}
async function getMeetingsFromCal() {
  const meetings = await chrome.runtime.sendMessage("getCalEntries");
  const { meetingsBookedByDay = {} } = await chrome.storage.sync.get("meetingsBookedByDay");
  const todaysBookedMeetings = meetingsBookedByDay[await getSelectedDay()] || [];
  const { bookedMeetings: bookedMeetingTitles } = await chrome.storage.sync.get("bookedMeetings");
  const aggregatedMeetings = getAggregatedMeetings(
    meetings,
    todaysBookedMeetings,
    bookedMeetingTitles
  );
  return aggregatedMeetings;
}
function openOptionsPage() {
  chrome.runtime.openOptionsPage();
}
async function testConnection(data) {
  try {
    const test = await fetch(`${data.jiraBaseUrl}/rest/api/3/issue/${data.jiraDefaultTicket}`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${btoa(`${data.email}:${data.jiraToken}`)}`,
        Accept: "application/json",
        "X-Atlassian-Token": "no-check"
      }
    });
    if (test.status !== 200) {
      throw new Error("Could not connect to Jira");
    }
  } catch (e) {
    throw new Error("Could not connect to Jira");
  }
}
async function storeData(data) {
  try {
    await testConnection(data);
    if (false)
      ;
    await chrome.storage.sync.set(data);
  } catch (e) {
    throw e;
  }
}
async function getIssueKeyForMeetingName(meetingTitle) {
  try {
    const { bookedMeetings } = await chrome.storage.sync.get(["bookedMeetings"]);
    if (bookedMeetings && Object.keys(bookedMeetings).includes(meetingTitle)) {
      return bookedMeetings[meetingTitle];
    }
    return chrome.storage.sync.get("jiraDefaultTicket").then((data) => data.jiraDefaultTicket);
  } catch (e) {
    console.error(e);
    return chrome.storage.sync.get("jiraDefaultTicket").then((data) => data.jiraDefaultTicket);
  }
}
async function saveIssueKeyForMeetingName(meeting, issue) {
  const { bookedMeetings } = await chrome.storage.sync.get("bookedMeetings");
  bookedMeetings[meeting] = issue;
  await chrome.storage.sync.set({ bookedMeetings });
}
async function createHash(message) {
  const msgUint8 = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest("SHA-256", msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  return hashHex;
}
export {
  getMeetingsFromCal as a,
  getSelectedDay as b,
  createHash as c,
  addMeetingBookedByDay as d,
  saveIssueKeyForMeetingName as e,
  getIssueKeyForMeetingName as g,
  openOptionsPage as o,
  storeData as s
};
