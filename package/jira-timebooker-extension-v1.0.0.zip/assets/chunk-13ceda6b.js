function getCalEntries(cb) {
  chrome.runtime.sendMessage("getCalEntries", cb);
}
async function testConnection(data) {
  try {
    const test = await fetch(`${data.jiraBaseUrl}/rest/api/3/issue/${data.jiraDefaultTicket}`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${btoa(`${data.email}:${data.jiraToken}`)}`,
        Accept: "application/json",
        "X-Atlassian-Token": "no-check"
      }
    });
    if (test.status !== 200) {
      throw new Error("Could not connect to Jira");
    }
  } catch (e) {
    throw new Error("Could not connect to Jira");
  }
}
async function storeData(data) {
  try {
    await testConnection(data);
    if (false)
      ;
    await chrome.storage.sync.set(data);
  } catch (e) {
    throw e;
  }
}
async function getIssueForMeeting(meeting) {
  try {
    const { bookedMeetings } = await chrome.storage.sync.get(["bookedMeetings"]);
    if (bookedMeetings && Object.keys(bookedMeetings).includes(meeting)) {
      return bookedMeetings[meeting];
    }
    return chrome.storage.sync.get("jiraDefaultTicket").then((data) => data.jiraDefaultTicket);
  } catch (e) {
    console.error(e);
    return chrome.storage.sync.get("jiraDefaultTicket").then((data) => data.jiraDefaultTicket);
  }
}
async function storeIssueForMeeting(meeting, issue) {
  const { bookedMeetings } = await chrome.storage.sync.get("bookedMeetings");
  bookedMeetings[meeting] = issue;
  await chrome.storage.sync.set({ bookedMeetings });
}
export {
  getCalEntries as a,
  storeIssueForMeeting as b,
  getIssueForMeeting as g,
  storeData as s
};
