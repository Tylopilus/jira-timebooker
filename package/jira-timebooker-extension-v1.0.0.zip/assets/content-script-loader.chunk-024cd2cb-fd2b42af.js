(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-024cd2cb.js")
    );
  })().catch(console.error);

})();
