import { g as getIssueForMeeting } from "./chunk-919c4c6d.js";
console.info("chrome-ext template-react-ts content script");
async function getMeetings() {
  const meetingElements = [...document.querySelectorAll("div[role=button][class^=root]")];
  if (!meetingElements.length)
    throw new Error("No meetings found");
  const meetings = await Promise.all(
    meetingElements.map(async (el) => {
      var _a, _b, _c;
      const matchedLabel = (_a = el.ariaLabel) == null ? void 0 : _a.match(/(\d{2}\:\d{2}).*(\d{2}\:\d{2})/i);
      const date = ((_b = document.querySelector(".YjxmP.zVmbM")) == null ? void 0 : _b.textContent) || (/* @__PURE__ */ new Date()).toDateString();
      const start = matchedLabel ? matchedLabel[1] : "00:00";
      const end = matchedLabel ? matchedLabel[2] : "00:00";
      const startTime = new Date([date, start].join(" ")).toISOString();
      const endTime = new Date([date, end].join(" ")).toISOString();
      const title = ((_c = el.getAttribute("title")) == null ? void 0 : _c.split("\n")[0].trim()) ?? "No title";
      const id = crypto.randomUUID();
      const ticketMatch = title.match(/\w+-\d+\s/i);
      const issueForMeeting = await getIssueForMeeting(title);
      const ticket = ticketMatch ? ticketMatch[0].trim() : issueForMeeting;
      return {
        id,
        startTime,
        endTime,
        start,
        end,
        title,
        ticket,
        booked: false,
        pending: false
      };
    })
  );
  return meetings;
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message === "getCalEntries") {
    getMeetings().then((meetings) => {
      sendResponse(meetings);
    });
  }
  return true;
});
