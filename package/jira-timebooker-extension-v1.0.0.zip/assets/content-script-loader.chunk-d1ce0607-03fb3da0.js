(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-d1ce0607.js")
    );
  })().catch(console.error);

})();
