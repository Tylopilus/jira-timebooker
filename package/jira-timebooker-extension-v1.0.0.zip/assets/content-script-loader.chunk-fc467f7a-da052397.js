(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-fc467f7a.js")
    );
  })().catch(console.error);

})();
