(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-180a8402.js")
    );
  })().catch(console.error);

})();
