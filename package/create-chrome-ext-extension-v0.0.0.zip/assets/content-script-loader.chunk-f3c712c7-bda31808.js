(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-f3c712c7.js")
    );
  })().catch(console.error);

})();
