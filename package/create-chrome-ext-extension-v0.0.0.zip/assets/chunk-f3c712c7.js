console.info("chrome-ext template-react-ts content script");
function getMeetings() {
  return new Promise((resolve, reject) => {
    const meetingElements = [...document.querySelectorAll("div[role=button][class^=root]")];
    if (!meetingElements.length)
      reject("No meetings found");
    const meetings = meetingElements.map((el) => {
      var _a, _b;
      const matchedLabel = (_a = el.ariaLabel) == null ? void 0 : _a.match(/(\d{2}\:\d{2}).*(\d{2}\:\d{2})/i);
      const start = matchedLabel ? matchedLabel[1] : "00:00";
      const end = matchedLabel ? matchedLabel[2] : "00:00";
      const startTime = new Date([(/* @__PURE__ */ new Date()).toDateString(), start].join(" ")).toISOString();
      const endTime = new Date([(/* @__PURE__ */ new Date()).toDateString(), end].join(" ")).toISOString();
      const title = ((_b = el.getAttribute("title")) == null ? void 0 : _b.split("\n")[0].trim()) ?? "No title";
      const id = crypto.randomUUID();
      const ticketMatch = title.match(/\w+-\d+\s/i);
      const ticket = ticketMatch ? ticketMatch[0].trim() : "CWAL-1";
      return { id, startTime, endTime, start, end, title, ticket, booked: false };
    });
    resolve(meetings);
  });
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message === "getCalEntries") {
    getMeetings().then(sendResponse).catch(console.error);
  }
});
